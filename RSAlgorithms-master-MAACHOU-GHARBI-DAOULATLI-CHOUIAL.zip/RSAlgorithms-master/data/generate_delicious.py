import pandas as pd
import sys
import argparse

# Créer un objet ArgumentParser
parser = argparse.ArgumentParser(description='Script pour générer les donnée epinions')

# Ajouter les arguments
parser.add_argument('--user_contacts', type=str, required=True, help='URL user_contacts.dat')
parser.add_argument('--user_taggedbookmarks', type=str, required=True, help='URL user_taggedbookmarks.dat')

args = parser.parse_args()

# Charger les données
contact_data = pd.read_csv(args.user_contacts, sep='\t', header=0)

rating_data = pd.read_csv(args.user_taggedbookmarks, sep='\t', header=0)

# Compter le nombre de tags par utilisateur et par URL
ratings = rating_data.groupby(['userID', 'bookmarkID']).size().reset_index(name='ratingCount')

# Normaliser les comptes (mettre à l'échelle de 1 à 5)
max_count = ratings['ratingCount'].max()
ratings['rating'] = ratings['ratingCount'].apply(lambda x: 1 + 4 * (x - 1) / (max_count - 1))

# Créer le fichier final avec userID, bookmarkID (en tant qu'itemID) et rating
final_data = ratings[['userID', 'bookmarkID', 'rating']]

filename = 'dl_trust.txt'

# Ouvrir un fichier texte en mode écriture
with open(filename, 'w') as fichier:
    for paire in contact_data.itertuples():
        # Écrire chaque paire suivi d'un '1'
        ligne = f"{paire.userID} {paire.contactID} {1}\n"
        fichier.write(ligne)

filename = 'dl_ratings.txt'
# Ouvrir un fichier texte en mode écriture
with open(filename, 'w') as fichier:
    for paire in final_data.itertuples():
        # Écrire chaque paire suivi d'un '1'
        ligne = f"{paire.userID} {paire.bookmarkID} {paire.rating}\n"
        fichier.write(ligne)